# CoasterPrint — self-hosted edition

A complete static image-to-SVG and layered-STL web app. Includes the working tracing, palette clustering,
compound paths, white-color handling, transparent boundaries, outside-edge smoothing,
monochrome pinhole controls, and automatic layered STL export from the hosted app.

## Deploy

1. Extract this ZIP.
2. Upload the CONTENTS of `site/` to your webserver's document root or a subfolder,
   for example `public_html/trace/`.
3. Open `https://your-domain.example/trace/` (with the trailing slash).

Keep the folder structure intact. There is no installation, build step, database,
Node.js, PHP, API key, ChatGPT account, or Sites subscription required.
Apache, nginx, IIS, cPanel hosting, and ordinary static hosts work.
Use HTTP or HTTPS; double-clicking index.html with file:// will not run Web Workers.
HTTPS is recommended for a public website.

## Test locally (optional)

With Python 3 installed, from the extracted directory run:

    python -m http.server 8000 --directory site

Open http://localhost:8000/ in a current Chrome, Edge, Firefox, or Safari browser.
Stop the server with Ctrl+C.

## Server settings

Serve `.html` as text/html, `.js` as application/javascript or text/javascript, and `.wasm` as application/wasm. The browser needs WebAssembly and module Web Workers. If you use a restrictive CSP, permit WebAssembly compilation (wasm-unsafe-eval) and same-origin workers.
The scripts and worker must remain on the same origin. If your server uses a Content
Security Policy, allow same-origin scripts and workers, inline styles, and blob: images.
Allow blob: downloads. Do not route requests for JavaScript files to an HTML fallback.
No CORS configuration is needed when served from a single origin.

The app also works in a subfolder because all resource URLs are relative.

## Privacy and processing

Images are decoded and traced in the visitor's browser and are not uploaded to your
server. This export makes no third-party requests: tracing and ZIP libraries are
included. Typography is bundled locally; no external font service is required.
Your webserver may still record ordinary page/asset access logs.

Limits: JPG/PNG, up to 10 files, 20 MB each. Images are traced at up to 1600 pixels on
the longest side. Larger originals are resized for tracing. Heavy batches depend on
the visitor's CPU and memory. SVG is generated as editable compound paths per color;
monochrome mode exports one black compound path. Pinhole area is measured at tracing
resolution. STL generation runs in a browser worker using the bundled Manifold WebAssembly engine. No server-side geometry software is needed.

## Layered STL export

Enable "Create coaster 3MF after tracing" (on by default) or click "Build / rebuild coaster" after tracing.
Defaults: finished width 100 mm; solid base 2 mm; raised SVG image 0.5 mm, total 2.5 mm.
Width is measured across the actual visible artwork; aspect ratio is preserved. You can
adjust width and layer thicknesses, then rebuild without retracing.

The base follows the visible outer outline and fills internal holes. Transparent exterior
space stays outside the base. Separate disconnected components remain separate bodies.
Raised image regions preserve SVG holes and sit at Z=2–2.5 mm with the default settings.
White is a printable part in color mode. Black-and-white mode has one raised black part.
Curves are tessellated for STL with a target chord tolerance of 0.0075 mm.

- "Bambu 3MF" is the recommended Bambu Studio export: one assembled object with a named
  base and a named part per SVG color. Import the 3MF, expand the object in the Objects
  list, select each part, and assign its filament. The file includes display colors and part names, but no printer or filament presets;
  use your current printer settings and choose filament slots in Bambu Studio.
- "STL (merged)" is a single merged model. It cannot retain separate selectable colors.
  It is appropriate for a single-filament print, not part-based color assignment.
- "Color parts ZIP" contains a base STL, one aligned STL per SVG color, colors.json, and
  Bambu Studio import instructions. Select all STL parts together and load them as ONE
  object with multiple parts, then assign filaments. Importing separately or auto-arranging
  can drop raised layers to the build plate and lose their alignment.
- For multiple traced images, "3D models ZIP" bundles their combined STLs and color ZIPs.

If every color fills the complete footprint, raising all colors by the same height produces
a flat-topped combined STL; the separate color parts preserve the image for multi-filament
printing. STL files do not encode colors. Layer heights are model geometry, not slicer
print-layer settings. Slicer settings, filament assignment, and print validation remain yours.

## Mesh validation and cleanup

The exporter validates the actual float32 output coordinates: triangles must have nonzero
area and every edge must have exactly two oppositely oriented incident faces. Failed
meshes are withheld and an error is shown. This supplements the solid engine's checks.
The geometry uses a 0.005 mm planar cleanup and 0.01 mm solid tolerance to remove
microscopic slivers that would otherwise collapse when written to STL. Features below
0.01 mm can be removed. 3MF mesh parts are individually closed solids; their contact
faces at the base/top interface are intentional, as in a standard multipart assembly.

## Files and editing

site/index.html — layout and styling
site/app.js — uploads, controls, preview, downloads
site/worker.js — tracing pipeline in a Web Worker
site/palette.js — perceptual color clustering
site/alpha.js — transparency and edge-background handling
site/edge.js — outer-edge smoothing
site/mono.js — monochrome silhouette and pinhole filling
site/stl.js — 3D workflow, settings and downloads
site/three-mf.js — multipart 3MF with named base and color components
site/stl-worker.js — solid base, raised image extrusion and boolean union
site/stl-geometry.js — SVG curve tessellation and binary STL writing
site/vendor/ — bundled ImageTracer.js, fflate, and Manifold JS/WASM

Production HTML uses content-fingerprinted script filenames. Editable logical source files are included too. If you edit the logical JavaScript sources, run `python refresh-assets.py` locally to regenerate the fingerprinted copies and HTML references, then upload the complete site directory. Python is optional for source editing; it is not required to host the app.

## Third-party notices

ImageTracer.js 1.2.6, Andras Jankovics — Unlicense / public domain.
Its full license is retained at the top of site/vendor/imagetracer.js.
fflate 0.8.2, Arjun Barrett — MIT. See site/vendor/fflate-LICENSE.txt.

Manifold 3.3.2, The Manifold Authors — Apache License 2.0.
See site/vendor/manifold-LICENSE.txt.

Export recovery: each part is checked independently. Cleanup retries are bounded at 0.02 mm, and an unmodified fallback preserves tiny color regions when an opening would erase them. A failed merged STL no longer blocks validated multipart 3MF / STL-part downloads. Any cleanup above 0.005 mm is reported on the card. Exact errors identify the failing part.

Failed-color contact recovery: after the normal cleanup attempts, a raised color part may be inset by 0.001, 0.002 or 0.005 mm to separate coincident contacts. This is applied only to a failed color part, never silently: the image card reports the applied separation and notes that microscopic regions can shrink or disappear. Mesh validation remains mandatory.

3MF import mode: these are standard MODEL-ONLY 3MF assemblies. No Metadata/model_settings.config or project_settings.config files are included, so they are not presented as complete Bambu print projects. Import geometry using your existing printer profile. Standard core components preserve part names, coordinates, and display colors.

## Bambu Studio 2.8.2.61 notice

Bambu Studio 2.8.2.61 can report "The 3mf file has invalid config, load geometry data only" for a valid model-only 3MF because no printer/nozzle preset is embedded. Click OK to load the model using the current printer settings. This notice does not mean the mesh is damaged. Expand the model in Objects to assign filaments to the named base and color parts. The app displays this explanation next to the 3D export settings.

## CoasterPrint visual design

A dark, responsive coaster-making page with red, yellow and blue accents, a bundled Inter typeface, vector artwork, and an image-to-SVG-to-3MF guide. All typography and artwork are included locally. Inter is distributed under the SIL Open Font License; see site/fonts/inter-LICENSE.txt.

## Coaster holder downloads

The Coaster holders section offers four supplied, unchanged STL models: 4-coaster and 6-coaster holders in round and square shapes, plus a download-all ZIP. Preview images, holder files and the holder pack are included under site/assets/holders and site/downloads. Overall dimensions appear on each card; check internal fit for your coaster sizes in your slicer.

Zero-area export errors now advise increasing Maximum colors (e.g. 4 to 6 or 8) and retracing the image before rebuilding 3D. This is guidance, not a guarantee that increasing colors will resolve every geometry problem.

## One coaster per plate: batch Bambu project

When at least two coasters have completed 3D conversion, the main 3MF button downloads
one Bambu project instead of separate files. Each coaster is centered on its own plate,
with its base and color parts kept in one assembly. Failed 3D conversions are excluded
and reported. Individual per-image 3MF downloads remain available. Open "One project.
One coaster per plate" for the individual-3MF ZIP option.

The default batch profile is a Bambu P1S with a 0.4 mm nozzle and a 256 x 256 mm bed,
using the supplied sample's starter print/PLA settings. The active printer is shown
in the maker. Assign/check filament colors and review print settings before slicing.
Only exact matches to template filament colors are preassigned; other parts start in
slot 1 and retain their intended color in their part names.

For another printer, select a project saved from your own Bambu Studio. This is read
locally: printer, filament and print settings are reused, while models, thumbnails,
author metadata and sliced G-code are not copied. Connection credential fields are
removed. Choose an unsliced project no larger than 64 MB. Reset restores the P1S default.

IMPORTANT: Open the exported 3MF AS A PROJECT in Bambu Studio to keep separate plates
and the included printer settings. Importing only its geometry can lose plate layout.
The layout follows Bambu Studio 2.8.2.61's plate grid (ceil(sqrt(N)) columns; 20% gap).
Up to 10 plates are supported; each coaster must fit the bed with a 5 mm edge margin.
Template wipe-tower locations are reused across new plates: review placement in Studio.

Includes site/batch-3mf.js and site/presets/bambu-p1s-04.json.

## Batch limit and perimeter smoothing

CoasterPrint enforces a hard 10-image limit across file-picker and drag/drop additions.
Multi-plate projects are capped at 10 coasters too. Large single images or complex models
can still take substantial browser memory; this limit does not guarantee crash prevention.

"Smooth outside edge" now has Gentle, Balanced (default), and Strong levels, independent
of the artwork's Detail level. The smoother operates only near the outside perimeter,
using edge-connected transparent space and pinning corners and color junctions.
Interior vector detail is left intact. Strong can soften tiny outline features.
Keep Detail at Balanced or Fine when preserving interior details is the priority.
3D curve tessellation uses a finer 0.0075 mm target chord tolerance to reduce faceting.
After changing smoothing settings, retrace the artwork to update the SVG and 3D models.

## r19: fresh tracing and a shared outer silhouette

Upload ALL contents of site/, including the fingerprinted JavaScript files. If your
webserver caches index.html aggressively, open /coasterprint-r26.html in the same directory
as index.html. It is a new entry filename and loads content-fingerprinted scripts.
The footer and new trace cards identify build r23. The versioned download ZIP also
avoids an older ZIP response being reused by browser or hosting caches.

There is no generated-image/SVG result cache. Retracing creates a new worker and decodes
the source again. Each SVG includes a trace run ID, timestamp, settings, perimeter-point
statistics, and a geometry ID in metadata. The same image/settings can legitimately
produce the same geometry ID on separate fresh runs. Changing tracing settings marks
old SVG/3D outputs stale and blocks their downloads until retracing completes.

Outside smoothing now follows a single alpha silhouette across color boundaries.
Antialiased edge bands no longer pin every color junction. Original colored paths
remain editable; standard SVG clipping and a perimeter-only underlay apply the shared
outline. CoasterPrint's 3D converter applies the same shared boundary and fills only
missing perimeter regions, keeping interior holes and artwork. Third-party SVG importers
need to support SVG clipPath/use; use CoasterPrint's 3MF for reliable slicer geometry.

If the image has no transparent outer background, the app reports that the exposed
outline is the image frame. For a circle or other shape inside a solid outer background,
enable Remove edge background and retrace. White enclosed inside the design stays filled.

asset-manifest.json lists the deployed build and generated script names.

## r20: remove opposite-color rim fragments

Remove edge color specks is enabled by default. It removes only small or thin connected color fragments entirely within 3 tracing pixels of the external silhouette, replacing them with the dominant rim color. Interior contours and holes are preserved. Turn it off for intentional small edge marks. Retrace and rebuild 3D models after changing the setting. The SVG and 3MF share this cleanup.

## r21: Bambu multi-plate project loading

Batch downloads include one numbered plate and one multipart coaster per successfully converted image, up to 10. The export now includes the Bambu project-dialect Application version required for Bambu Studio 2.8.2.61 to load project settings; CoasterPrint is identified in Description. Without this compatibility marker Bambu discarded the project settings and opened a single plate with models outside it. Open the downloaded 3MF as a project (File > Open Project), rather than importing only its geometry into an existing project.

## Edge cleanup

Remove edge color specks is enabled by default. It removes only small or thin connected color fragments entirely within 3 tracing pixels of the external silhouette, replacing them with the dominant rim color. Interior contours and holes are preserved. Turn it off for intentional small edge marks. Retrace and rebuild 3D models after changing the setting. The SVG and 3MF share this cleanup.

## r22: seal connected rim slivers

The new Seal thin outer rim checkbox is on by default in color mode. It applies the main rim color to the outermost 0.5% of the image width (about 0.5 mm at 100 mm wide). Unlike speck removal, this also covers long strips and fragments connected to larger background shapes. The SVG shows the same seal used to subtract the edge band from every other color in 3MF/STL. The transparent outer shape and alpha holes remain empty. Interior geometry away from this band is unchanged. Turn this setting off for intentionally multicolored outer edges. After uploading this update, retrace from the original image and rebuild your 3D models.

## r23: automatic Bambu filament colors

Single and multi-plate 3MF downloads are now full Bambu projects. They include the traced palette in filament_colour and assign every image mesh to its matching filament slot. Identical colors share a slot across plates. The base reuses the main rim color (or first image color when no rim is detected), avoiding an extra filament. Up to 32 distinct colors are supported per project; batches above that limit must use fewer tracing colors or be split.

The selected P1S / 0.4 mm profile, or your optional Bambu template, supplies printer and material settings. A color already present in the template keeps its material profile; new colors reuse the first non-support profile. Printer/nozzle settings are preserved. Color slots are resized together with their material and extruder-variant settings. Review the material types and temperatures for your actual spools.

Download 3MF and use File > Open Project in Bambu Studio to retain colors, plates and part assignments. Match the virtual filament slots to your actual AMS spools or manual filament changes before printing. Importing the SVG or STL alone cannot transfer these assignments. Changing the printer template refreshes individual 3MF files without rebuilding geometry. After installing r23, rebuild existing coasters to create the new colored project exports.

## r24: compact page and image guidance

Removed the large introduction and decorative hero graphic. The 01–03 directions now follow the header. Step 01 recommends clear shapes and solid colors, and explains that photos, shading and gradients do not trace well. Tracing and export behavior are unchanged from r23.

## r25: tighter page spacing

Reduced vertical padding in sections, panels and the header, and tightened heading/control gaps. Kept input and button sizes and horizontal spacing comfortable. Mobile spacing is adjusted separately. Tracing and export behavior are unchanged.

## r26: one palette across a batch

In color mode, a batch now selects one shared palette from all the original images before tracing. Maximum colors limits the whole batch palette, rather than giving each image a separate set of shades. Every image uses those exact RGB values, and the multi-plate 3MF uses the same shared filament slots. Images can use fewer colors when some palette colors are absent.

Palette sampling and tracing run sequentially in workers, with bounded samples per image; transparent pixels and an enabled removed edge background do not consume color slots. The color-reading pass adds some processing time. Adding images to an existing traced batch marks earlier results stale so the entire batch is retraced with its new palette. Retrace all images and rebuild models after updating. Single-image tracing and black-and-white behavior are unchanged.
