COASTERPRINT COASTER HOLDERS

Four supplied STL designs: round and square holders for sets of 4 and 6 coasters.
The models are provided unchanged. Listed dimensions are overall sizes, not internal clearance. Check fit against your coaster dimensions in the slicer before printing.

4-coaster round holder: 106.5 × 106.5 × 16.6 mm
6-coaster round holder: 106.5 × 106.5 × 31.9 mm
4-coaster square holder: 106.0 × 106.0 × 16.6 mm
6-coaster square holder: 106.0 × 106.0 × 19.2 mm