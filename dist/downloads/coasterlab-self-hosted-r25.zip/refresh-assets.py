from pathlib import Path
import hashlib,re,json
root=Path(__file__).resolve().parent/'site';manifest={}
order=['palette.js','alpha.js','edge.js','mono.js','edge-artifacts.js','stl-geometry.js','filament-palette.js','three-mf.js','worker.js','stl-worker.js','app.js','stl.js','batch-3mf.js']
# Remove earlier generated copies only; keep editable logical source files.
previous=json.loads((root/'asset-manifest.json').read_text()).get('scripts',{}) if (root/'asset-manifest.json').exists() else {}
for name in previous.values():
 if False and re.fullmatch(r'[a-zA-Z0-9-]+\.[0-9a-f]{12}\.js',name) and (root/name).exists():(root/name).unlink()
for name in order:
 source=(root/name).read_text()
 for logical,hashed in manifest.items():source=re.sub(r'(?<![A-Za-z0-9_.-])'+re.escape(logical)+r'(?:\?[^\s\'"<>]+)?',hashed,source)
 digest=hashlib.sha256(source.encode()).hexdigest()[:12];filename=name[:-3]+'.'+digest+'.js';(root/filename).write_text(source);manifest[name]=filename
p=root/'index.html';source=p.read_text()
# Re-running updates references left by an earlier fingerprint pass.
for logical,hashed in manifest.items():
 base=re.escape(logical[:-3]);source=re.sub(r'(?<![A-Za-z0-9_.-])'+base+r'(?:\.[0-9a-f]{12})?\.js(?:\?[^\s\'"<>]+)?',hashed,source)
p.write_text(source);(root/'coasterlab-r25.html').write_text(source);(root/'asset-manifest.json').write_text(json.dumps({'build':'coasterlab-r25','scripts':manifest},indent=2))
print('Fingerprinted',len(manifest),'first-party scripts; created coasterlab-r25.html')
